chmod 755 bin/libftdi1-config
chmod 755 bin/libusb-config
chmod 755 bin/openocd
chmod 755 lib/libusb-1.0.la
chmod 755 lib/libusb.la
chmod 755 lib/python3.8/site-packages/_ftdi1.so
chmod 755 chmod755.sh
